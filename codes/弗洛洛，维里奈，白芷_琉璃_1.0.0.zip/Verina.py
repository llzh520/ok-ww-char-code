import time
from src.char.BaseChar import BaseChar, SwitchPriority

class Verina(BaseChar):
    """Verina 自动战斗(辅助/治疗): 循环输出直至协奏满，满协奏后切换至弗洛洛。"""
    NORMAL_ATTACK_TIME: float = 0.6
    JUMP_ATTACK_TIME: float = 0.5
    HEAVY_ATTACK_TIME: float = 0.7
    RECOVER_TIME: float = 0.8
    FIELD_TIME: float = 6.5
    HEAVY_ATTACK_INTERVAL: float = 8.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = -1

    def do_perform(self):
        self.perform_combat()
        self.switch_next_char()
        
    def perform_combat(self):
        """循环执行连招，仅协奏满时停止并准备切人。"""
        while not self.is_con_full():
            self.start = time.time()
            self.continues_normal_attack(self.NORMAL_ATTACK_TIME)
            # 依次放 大招 -> E -> 声骸; 每步前检查协奏满，满则提前退出连招
            for cast_skill in (self.cast_liberation, self.cast_resonance, self.cast_echo):
                if self.should_stop():
                    break
                cast_skill()
            if self.should_stop():
                break
            self.task.wait_until(lambda: self.task.in_team()[0], time_out=2.0)
            self.sleep(self.RECOVER_TIME)
            
            if self.is_mouse_forte_full() and self.can_heavy_attack():
                self.heavy_attack(self.HEAVY_ATTACK_TIME)
                self.last_heavy = time.time()
            self.task.jump(after_sleep=0.01)
            self.continues_normal_attack(self.JUMP_ATTACK_TIME)

    def cast_resonance(self):
        """共鸣(E)可用则放。"""
        if self.resonance_available():
            self.click_resonance(send_click=True, time_out=0)

    def cast_liberation(self):
        """解放(大招)可用则放。"""
        if self.liberation_available():
            self.click_liberation()

    def cast_echo(self):
        """声骸可用则放。"""
        if self.echo_available():
            self.click_echo(time_out=0)

    def should_stop(self):
        """仅协奏满时停止连招并进入切人流程。"""
        return self.is_con_full()

    def can_heavy_attack(self):
        """距上次重击是否已超过最小间隔(扣除冻结时间)。"""
        return self.time_elapsed_accounting_for_freeze(self.last_heavy) >= self.HEAVY_ATTACK_INTERVAL

    def field_time_out(self):
        """在场时间是否已超过上限(扣除冻结时间)。"""
        return self.time_elapsed_accounting_for_freeze(self.start) >= self.FIELD_TIME

    def switch_next_char(self, post_action=None, free_intro=False, target_low_con=False):
        """满协奏时优先切换到弗洛洛(char_phrolova)。"""
        # 切换前通用状态预处理
        self.is_forte_full()
        self.has_intro = False
        self.has_sub_dps_intro = False
        self._liberation_available = self.liberation_available()
        self.use_tool_box()

        # 查找队伍中的弗洛洛
        target_char = None
        for char in self.task.chars:
            if char is not None and char.char_name == "char_phrolova":
                target_char = char
                break

        if target_char is not None:
            switch_key = str(target_char.index + 1)
            # 等待切换完成并更新角色状态
            start = time.time()
            while time.time() - start < 6:
                in_team, current_index, count = self.task.in_team()
                if in_team and current_index != self.index:
                    for char in self.task.chars:
                        if char:
                            char.is_current_char = (char.index == current_index)
                    break
                self.task.send_key(switch_key)
                self.sleep(0.2, False)
            # 标记满协奏下场并更新buff时间
            self.switch_out(con_full=True)
            if post_action is not None:
                post_action()
            return

        # 未找到目标角色时回退到默认切换逻辑
        super().switch_next_char(
            post_action=post_action,
            free_intro=free_intro,
            target_low_con=target_low_con
        )

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_hiyuki'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
